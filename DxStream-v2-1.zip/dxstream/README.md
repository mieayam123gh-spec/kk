# DXSTREAM

DXSTREAM adalah aplikasi streaming berbasis Express dengan alur verifikasi, landing page, login/daftar, profil, admin, dan **chat global grup** — sekarang dengan **UI bertema Netflix (dark + red accent)** yang responsif (otomatis menyesuaikan desktop / tablet / HP).

## Menjalankan

```bash
npm install
npm start
```

Buka `http://localhost:2255/`. Endpoint TMDB dipanggil melalui `/api/tmdb/*`, sehingga API key tidak pernah dikirim ke browser. Untuk deployment, salin `.env.example` ke `.env` atau set environment variable pada host.

## Alur halaman

- `/` atau `/verifikasi.html`: verifikasi manusia, otomatis ke landing setelah 2 detik.
- `/landing-page.html`: landing DXSTREAM (hero Netflix-style).
- `/login/daftar.html`: masuk atau daftar; akun disimpan ke `users.json`.
- `/index.html`: streaming, profil, chat global, dan panel admin.

## Admin awal (fix login admin)

Pada setiap boot, backend otomatis menyinkronkan akun admin dari `.env`:

- Username: `DensXD`
- Password: `DensXD@admin22`

> Password admin selalu direset sesuai env saat server menyala — jadi kalau lupa password, cukup ubah `ADMIN_PASSWORD` di `.env`, restart server, lalu login.

Password disimpan sebagai hash scrypt; session memakai cookie HttpOnly.

## Fitur komunitas (chat global = group chat)

- Realtime Socket.IO broadcast ke semua user online.
- Online count + daftar user online (chips) di atas chat.
- Notifikasi presence: "X bergabung / meninggalkan chat".
- Typing indicator: "X sedang mengetik…" (throttled).
- Pesan teks, foto (maks 5 MB), reply berbasis message ID, emoji, reaction toggle.
- Centang biru untuk akun terverifikasi; badge ADMIN untuk admin.
- Admin bisa **menghapus pesan siapa pun**; user biasa hanya pesannya sendiri.
- Pesan diappend langsung ke sender (anti-duplicate via `data-message-id`).

## UI Netflix-style & responsif

- Tema gelap (#141414) + accent merah Netflix (#e50914) + gold badge rating.
- Top nav: brand + Home / Movies / TV Shows / New & Popular / Community + search icon + bell + avatar.
- Hero banner 50–70vh (menyesuaikan device), gradient overlay Netflix-style, Play & More Info buttons.
- Horizontal poster rows dengan hover scale + circular red play button.
- Ranking row dengan badge angka besar outline.
- Mobile (<768px): bottom nav bar 4-tab (Beranda / Pencarian / Chat / Akun).
- Tablet/Desktop (≥768px): top nav links aktif, bottom nav disembunyikan, poster lebih besar.
- Layout otomatis pindah sesuai device yang masuk.

Credit By DensXD.

---

## Pembaruan v2 (redesign + Shorts + auto-login)

**Tampilan**: gaya terang hangat ala Sairipedia (kanvas `#F4F4F2`, kartu putih membulat, navbar pil melayang, tombol tinta) plus mode gelap (tombol Dark/Light, tersimpan di perangkat). Animasi scroll-reveal lewat `reveal.js`. Warna aksen cukup diubah di `--accent` pada `public/base.css`.

**Login tersimpan**: setelah login, server mengirim `deviceToken` (180 hari) yang disimpan di `localStorage` (`dx_auth`). Di `landing-page.html`, tombol Masuk/Mulai langsung menuju `/index.html` bila perangkat dikenali. Token divalidasi lewat `POST /api/auth/resume`.

**Shorts** (`/index.html` → tab Shorts):
- Feed otomatis dari TMDB (`GET /api/shorts/feed?page=n`), tanpa posting manual. Klip = video YouTube resmi (Clip > Teaser > Trailer), hanya ±45 detik yang diputar dan di-loop.
- Pemutar YouTube IFrame API: seek bar bisa digeser, tap = jeda, tap dua kali = like, keyboard: ↑/↓ pindah, Spasi jeda, ←/→ ±5 detik, M suara, L like, C komentar.
- Like video, komentar, like komentar tersimpan di `shorts.json`. Like otomatis menyimpan drama ke "Drama Tersimpan" (Akun + Beranda).
- Sponsor = studio/jaringan produksi dari data TMDB.
- "Tonton Film Lengkap" membuka halaman film dan memutarnya. Komentar halaman film memakai thread yang sama dengan Shorts.

**Film penuh**: SERVER 1 (VidLink) mendukung `startAt` dan progres via postMessage, sehingga muncul "Lanjut dari mm:ss". Server lain memakai pemutar embed masing-masing (posisi tidak bisa dikontrol dari luar).

Tes logika feed: `node test/shorts.test.js`.
