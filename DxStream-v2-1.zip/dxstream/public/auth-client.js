/* Login perangkat tersimpan di localStorage (dx_auth) -> dipakai landing page & halaman utama. */
(function () {
  var KEY = 'dx_auth';
  function read() { try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) { return null; } }
  function save(user, token) {
    var old = read() || {};
    try { localStorage.setItem(KEY, JSON.stringify({ user: { id: user.id, username: user.username, role: user.role, verified: !!user.verified }, token: token || old.token || null, at: Date.now() })); } catch (e) {}
  }
  function clear() { try { localStorage.removeItem(KEY); } catch (e) {} }
  async function post(url, body) { return fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) }); }
  /* Mengembalikan user jika perangkat ini masih login (cookie valid ATAU token perangkat valid), selain itu null. */
  async function verify() {
    try {
      var r = await fetch('/api/auth/me', { cache: 'no-store' });
      var d = await r.json();
      if (d && d.user) { save(d.user); return d.user; }
    } catch (e) { var offline = read(); return offline ? offline.user : null; }
    var a = read();
    if (a && a.token) {
      try {
        var res = await post('/api/auth/resume', { token: a.token });
        if (res.ok) { var data = await res.json(); save(data.user, data.deviceToken); return data.user; }
        if (res.status === 401) clear();
      } catch (e) { return a.user; }
    }
    return null;
  }
  window.DXAuth = { get: read, save: save, clear: clear, verify: verify };
})();
