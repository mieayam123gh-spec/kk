/* ==========================================================================
   DXSTREAM SHORTS
   - Feed dibangun server dari TMDB (tidak ada posting manual): /api/shorts/feed
   - Klip = video YouTube resmi (Clip/Teaser/Trailer) yang hanya diputar ±45 detik, otomatis loop
   - Pemutar: YouTube IFrame API, jadi posisi video benar-benar bisa diatur (seek bar bisa digeser)
   - Like, komentar, like komentar tersimpan di server; "Tonton Film Lengkap" membuka halaman film
   ========================================================================== */
(function () {
  'use strict';
  var feed = document.getElementById('shortsFeed');
  if (!feed) return;

  var stage = document.getElementById('shortsStage');
  var sheet = document.getElementById('commentSheet');
  var backdrop = document.getElementById('sheetBackdrop');
  var modal = document.getElementById('detailModal');
  var ic = function (n) { return '<svg class="ic"><use href="/icons.svg#' + n + '"/></svg>'; };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]; }); };
  var fmt = function (s) { s = Math.max(0, Math.floor(s)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
  var toast = function (m) { if (window.showToast) window.showToast(m); };
  var store = {
    get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  };

  var S = {
    items: [], page: 0, loading: false, visible: false, modalOpen: false,
    activeIdx: -1, activeKey: null, player: null, playerCard: null, win: null, tok: 0, tick: null,
    dragging: false, fill: store.get('dx_shorts_fill') === '1', userUnmuted: store.get('dx_shorts_unmuted') === '1', ytP: null, cmtItem: null
  };
  stage.classList.toggle('fill', S.fill);

  /* ---------- YouTube IFrame API ---------- */
  function loadYT() {
    if (S.ytP) return S.ytP;
    S.ytP = new Promise(function (resolve, reject) {
      if (window.YT && window.YT.Player) return resolve(window.YT);
      var prev = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = function () { if (prev) prev(); resolve(window.YT); };
      var s = document.createElement('script');
      s.src = 'https://www.youtube.com/iframe_api'; s.async = true;
      s.onerror = function () { S.ytP = null; reject(new Error('YouTube tidak dapat dimuat')); };
      document.head.appendChild(s);
    });
    return S.ytP;
  }

  /* ---------- Feed ---------- */
  function skeleton() { feed.innerHTML = '<div class="short-skel" id="shortsSkel">Memuat klip…</div>'; }
  function message(text, withRetry) {
    var el = document.createElement('div'); el.className = 'shorts-msg'; el.id = 'shortsMsg';
    el.innerHTML = ic('zap') + '<p>' + esc(text) + '</p>' + (withRetry ? '<button class="btn btn-accent btn-sm" data-act="retry">Coba lagi</button>' : '');
    var old = document.getElementById('shortsMsg'); if (old) old.remove();
    feed.appendChild(el);
  }

  async function loadMore() {
    if (S.loading) return;
    S.loading = true;
    var got = 0, tries = 0;
    try {
      while (got === 0 && tries < 3) {
        S.page++; tries++;
        var r = await fetch('/api/shorts/feed?page=' + S.page);
        if (r.status === 401) { location.replace('/login/daftar.html?mode=login'); return; }
        var d = await r.json().catch(function () { return {}; });
        if (!r.ok) { S.page--; throw new Error(d.error || 'Gagal memuat Shorts.'); }
        var fresh = (d.items || []).filter(function (it) { return !S.items.some(function (x) { return x.key === it.key; }); });
        got = fresh.length;
        if (got) { var start = S.items.length; S.items = S.items.concat(fresh); appendCards(start); }
      }
      if (!got && !S.items.length) { var sk = document.getElementById('shortsSkel'); if (sk) sk.remove(); message('Belum ada klip yang tersedia. Coba lagi sebentar.', true); }
    } catch (e) {
      var sk2 = document.getElementById('shortsSkel'); if (sk2) sk2.remove();
      if (!S.items.length) message(e.message, true); else toast(e.message);
    } finally { S.loading = false; }
  }

  function cardHTML(it, i) {
    var sp = it.sponsors || [];
    var chips = sp.slice(0, 2).map(function (s) {
      return '<button class="sp-chip" data-act="sponsors" type="button"><span class="sp-label">Sponsor</span>' + (s.logo ? '<img src="' + esc(s.logo) + '" alt="" loading="lazy">' : '') + '<span>' + esc(s.name) + '</span></button>';
    }).join('') + (sp.length > 2 ? '<button class="sp-chip more" data-act="sponsors" type="button">+' + (sp.length - 2) + '</button>' : '');
    var list = sp.map(function (s) {
      return '<li>' + (s.logo ? '<img src="' + esc(s.logo) + '" alt="" loading="lazy">' : '<span class="sp-ph">' + ic('building') + '</span>') + '<div><b>' + esc(s.name) + '</b><small>' + esc(s.kind) + (s.country ? ' • ' + esc(s.country) : '') + '</small></div></li>';
    }).join('');
    var meta = [it.year, it.type === 'tv' ? 'Series' : 'Film'].concat(it.genres || []).filter(Boolean).map(esc).join(' • ');
    var bg = esc(it.backdrop || it.poster || '');
    return '<article class="short-card' + (S.userUnmuted ? ' unmuted' : '') + '" data-i="' + i + '" data-key="' + esc(it.key) + '">' +
      '<div class="short-bg" style="background-image:url(\'' + bg + '\')"></div>' +
      '<div class="short-video"><div class="yt-slot"></div>' + (bg ? '<img class="short-poster" src="' + bg + '" alt="" loading="lazy">' : '') + '</div>' +
      '<div class="short-shade"></div>' +
      '<div class="short-tap"></div>' +
      '<div class="short-flash"><div class="center-ico">' + ic('play') + '</div></div>' +
      '<div class="short-top"><span class="short-badge">' + esc(it.video.kind === 'Trailer' ? 'Cuplikan' : it.video.kind === 'Teaser' ? 'Teaser' : 'Klip') + '</span>' +
        '<div class="short-tools"><span class="mute-hint">Ketuk untuk suara</span>' +
        '<button class="tool-btn" data-act="mute" type="button" aria-label="Suara"></button>' +
        '<button class="tool-btn" data-act="fit" type="button" aria-label="Isi layar">' + ic('maximize') + '</button></div></div>' +
      '<div class="short-rail">' +
        '<button class="rail-btn like-btn' + (it.liked ? ' liked' : '') + '" data-act="like" type="button"><span class="circle">' + ic('heart') + '</span><span class="cnt-like">' + (it.likes || 0) + '</span></button>' +
        '<button class="rail-btn" data-act="comment" type="button"><span class="circle">' + ic('message') + '</span><span class="cnt-cmt">' + (it.comments || 0) + '</span></button>' +
        (sp.length ? '<button class="rail-btn" data-act="sponsors" type="button"><span class="circle">' + ic('building') + '</span><span>Sponsor</span></button>' : '') +
        '<button class="rail-btn" data-act="share" type="button"><span class="circle">' + ic('share') + '</span><span>Bagikan</span></button>' +
      '</div>' +
      '<div class="short-info">' +
        (sp.length ? '<div class="sp-row">' + chips + '</div><ul class="sp-list">' + list + '</ul>' : '') +
        '<h3 class="short-title">' + esc(it.title) + '</h3>' +
        '<div class="short-meta">' + (it.rating ? '<span class="star">★ ' + esc(it.rating) + '</span>' : '') + '<span>' + meta + '</span></div>' +
        (it.overview ? '<p class="short-overview" data-act="overview">' + esc(it.overview) + '</p>' : '') +
        '<button class="btn btn-accent btn-sm watch-btn" data-act="watch" type="button">' + ic('play') + ' Tonton Film Lengkap</button>' +
      '</div>' +
      '<div class="short-seek"><time class="t-cur">0:00</time><div class="seek-bar" role="slider" aria-label="Posisi video"><span class="fill"></span><span class="thumb"></span></div><time class="t-dur">' + fmt(it.video.end - it.video.start) + '</time></div>' +
    '</article>';
  }

  function appendCards(from) {
    var sk = document.getElementById('shortsSkel'); if (sk) sk.remove();
    var msg = document.getElementById('shortsMsg'); if (msg) msg.remove();
    var html = '';
    for (var i = from; i < S.items.length; i++) html += cardHTML(S.items[i], i);
    feed.insertAdjacentHTML('beforeend', html);
    for (var j = from; j < S.items.length; j++) { var c = feed.children[j]; paintMute(c); io.observe(c); }
  }

  /* ---------- Aktivasi kartu (yang terlihat penuh) ---------- */
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) { if (e.isIntersecting && e.intersectionRatio >= 0.6) activate(e.target); });
  }, { root: feed, threshold: [0.6, 0.9] });

  function activate(card) {
    var i = +card.dataset.i, it = S.items[i]; if (!it) return;
    Array.prototype.forEach.call(feed.querySelectorAll('.short-card.active'), function (c) { if (c !== card) c.classList.remove('active'); });
    card.classList.add('active');
    S.activeIdx = i; S.activeKey = it.key;
    if (i >= S.items.length - 3) loadMore();
    if (S.visible && !S.modalOpen) mount(card, it);
  }

  async function mount(card, it) {
    if (S.playerCard === card && S.player) return;
    unmount();
    var tok = ++S.tok;
    card.classList.add('loading');
    var YT;
    try { YT = await loadYT(); } catch (e) { cardError(card, 'Pemutar YouTube tidak dapat dimuat. Periksa koneksi internet.'); return; }
    if (tok !== S.tok || !S.visible || S.modalOpen) return;
    var slot = card.querySelector('.yt-slot'); slot.innerHTML = '';
    var holder = document.createElement('div'); slot.appendChild(holder);
    var win = { start: it.video.start, end: it.video.end, ok: false };
    S.win = win; S.playerCard = card;
    S.player = new YT.Player(holder, {
      videoId: it.video.yt,
      host: 'https://www.youtube-nocookie.com',
      playerVars: { autoplay: 1, controls: 0, disablekb: 1, fs: 0, modestbranding: 1, playsinline: 1, rel: 0, iv_load_policy: 3, start: Math.floor(win.start), mute: 1, origin: location.origin },
      events: {
        onReady: function (ev) { onReady(ev, tok, card); },
        onStateChange: function (ev) { onState(ev, tok, card); },
        onError: function () { onPlayerError(tok, card, it); }
      }
    });
  }

  function unmount() {
    S.tok++;
    stopTick();
    if (S.player) { try { S.player.destroy(); } catch (e) {} }
    if (S.playerCard) {
      var slot = S.playerCard.querySelector('.yt-slot'); if (slot) slot.innerHTML = '';
      S.playerCard.classList.remove('started', 'paused', 'buffering', 'loading', 'dragging');
    }
    S.player = null; S.playerCard = null; S.win = null; S.dragging = false;
  }

  function onReady(ev, tok, card) {
    var p = ev.target;
    if (tok !== S.tok) { try { p.destroy(); } catch (e) {} return; }
    if (S.userUnmuted) { p.unMute(); p.setVolume(100); } else p.mute();
    p.seekTo(S.win.start, true);
    p.playVideo();
    startTick();
    setTimeout(function () {                  // autoplay diblokir browser? tampilkan tombol putar
      if (tok !== S.tok || !S.player) return;
      var st = S.player.getPlayerState && S.player.getPlayerState();
      if (st === -1 || st === 5 || st === 2) { card.classList.remove('loading'); card.classList.add('paused'); }
    }, 3000);
  }
  function onState(ev, tok, card) {
    if (tok !== S.tok) return;
    var st = ev.data;
    if (st === 1) { card.classList.add('started'); card.classList.remove('paused', 'buffering', 'loading'); }
    else if (st === 2) { if (!S.dragging) card.classList.add('paused'); card.classList.remove('buffering'); }
    else if (st === 3) card.classList.add('buffering');
    else if (st === 0) { S.player.seekTo(S.win.start, true); S.player.playVideo(); }
  }
  function onPlayerError(tok, card, it) {
    if (tok !== S.tok) return;
    stopTick();
    card.classList.remove('loading', 'buffering'); card.classList.add('paused');
    cardError(card, 'Klip ini tidak bisa diputar di sini. Melewati…');
    var next = S.activeIdx + 1;
    if (next < S.items.length) setTimeout(function () { if (S.activeKey === it.key) goTo(next); }, 1400);
  }
  function cardError(card, text) {
    var old = card.querySelector('.card-error'); if (old) old.remove();
    var el = document.createElement('div'); el.className = 'card-error'; el.textContent = text; card.appendChild(el);
    setTimeout(function () { el.remove(); }, 3200);
  }

  /* ---------- Progres & loop segmen ---------- */
  function startTick() {
    stopTick();
    S.tick = setInterval(function () {
      var p = S.player, card = S.playerCard, w = S.win;
      if (!p || !card || !w || typeof p.getCurrentTime !== 'function') return;
      var dur = p.getDuration && p.getDuration();
      if (dur > 0 && !w.ok) {                  // sesuaikan jendela klip dengan durasi asli video
        if (w.start >= dur - 3) w.start = 0;
        w.end = Math.min(w.end, dur - 0.4);
        if (w.end - w.start < 4) { w.start = 0; w.end = Math.max(4, dur - 0.4); }
        w.ok = true;
        card.querySelector('.t-dur').textContent = fmt(w.end - w.start);
      }
      if (S.dragging) return;
      var t = p.getCurrentTime();
      if (t >= w.end - 0.2) { p.seekTo(w.start, true); return; }
      paintProgress(card, (t - w.start) / (w.end - w.start), t - w.start);
    }, 200);
  }
  function stopTick() { if (S.tick) { clearInterval(S.tick); S.tick = null; } }
  function paintProgress(card, pct, secs) {
    pct = Math.min(1, Math.max(0, pct || 0));
    card.querySelector('.seek-bar').style.setProperty('--p', pct);
    card.querySelector('.t-cur').textContent = fmt(secs);
  }

  /* ---------- Atur posisi video: seek bar bisa digeser ---------- */
  var lastSeek = 0;
  function seekFromPointer(e, bar, card, force) {
    var r = bar.getBoundingClientRect();
    var pct = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
    var w = S.win; if (!w || !S.player) return;
    var secs = pct * (w.end - w.start);
    paintProgress(card, pct, secs);
    var now = Date.now();
    if (force || now - lastSeek > 90) { lastSeek = now; S.player.seekTo(w.start + secs, true); }
  }
  feed.addEventListener('pointerdown', function (e) {
    var bar = e.target.closest('.seek-bar'); if (!bar) return;
    var card = bar.closest('.short-card');
    if (card !== S.playerCard || !S.player || !S.win) return;
    e.preventDefault(); e.stopPropagation();
    S.dragging = true; card.classList.add('dragging');
    try { bar.setPointerCapture(e.pointerId); } catch (_) {}
    seekFromPointer(e, bar, card, true);
    var move = function (ev) { seekFromPointer(ev, bar, card, false); };
    var up = function (ev) {
      bar.removeEventListener('pointermove', move); bar.removeEventListener('pointerup', up); bar.removeEventListener('pointercancel', up);
      seekFromPointer(ev, bar, card, true);
      S.dragging = false; card.classList.remove('dragging');
    };
    bar.addEventListener('pointermove', move); bar.addEventListener('pointerup', up); bar.addEventListener('pointercancel', up);
  });
  function seekBy(sec) {
    if (!S.player || !S.win) return;
    var t = Math.min(S.win.end - 0.3, Math.max(S.win.start, S.player.getCurrentTime() + sec));
    S.player.seekTo(t, true);
    paintProgress(S.playerCard, (t - S.win.start) / (S.win.end - S.win.start), t - S.win.start);
  }
  function togglePlay() {
    if (!S.player || !S.playerCard) return;
    var st = S.player.getPlayerState();
    if (st === 1 || st === 3) { S.player.pauseVideo(); S.playerCard.classList.add('paused'); }
    else { S.player.playVideo(); S.playerCard.classList.remove('paused'); }
  }

  /* ---------- Suara & mode layar ---------- */
  function paintMute(card) {
    var b = card.querySelector('[data-act="mute"]'); if (!b) return;
    b.innerHTML = ic(S.userUnmuted ? 'volume' : 'volume-x');
    card.classList.toggle('unmuted', S.userUnmuted);
  }
  function setMuted(m) {
    S.userUnmuted = !m; store.set('dx_shorts_unmuted', m ? '0' : '1');
    if (S.player) { if (m) S.player.mute(); else { S.player.unMute(); S.player.setVolume(100); } }
    Array.prototype.forEach.call(feed.querySelectorAll('.short-card'), paintMute);
  }
  function toggleFill() { S.fill = !S.fill; stage.classList.toggle('fill', S.fill); store.set('dx_shorts_fill', S.fill ? '1' : '0'); toast(S.fill ? 'Mode isi layar' : 'Mode pas layar'); }

  /* ---------- Like ---------- */
  function paintLike(card, it) {
    var b = card.querySelector('.like-btn'); b.classList.toggle('liked', !!it.liked);
    card.querySelector('.cnt-like').textContent = it.likes || 0;
  }
  async function toggleLike(card, it, forceOn) {
    var want = forceOn ? true : !it.liked;
    if (want === it.liked) return;
    it.liked = want; it.likes = Math.max(0, (it.likes || 0) + (want ? 1 : -1)); paintLike(card, it);   // optimistis
    try {
      var r = await fetch('/api/shorts/' + it.key + '/like', { method: 'POST' });
      var d = await r.json().catch(function () { return {}; });
      if (!r.ok) throw new Error(d.error || 'Gagal.');
      it.liked = d.liked; it.likes = d.likes; paintLike(card, it);
      toast(d.liked ? 'Disukai. Drama tersimpan otomatis.' : 'Dihapus dari tersimpan.');
      if (window.DXApp) window.DXApp.refreshSaved();
    } catch (e) {
      it.liked = !want; it.likes = Math.max(0, it.likes + (want ? -1 : 1)); paintLike(card, it); toast(e.message || 'Gagal menyukai.');
    }
  }
  function burst(card, e) {
    var r = card.getBoundingClientRect();
    var el = document.createElement('div'); el.className = 'heart-burst'; el.innerHTML = ic('heart');
    el.style.left = (e.clientX - r.left) + 'px'; el.style.top = (e.clientY - r.top) + 'px';
    card.appendChild(el); setTimeout(function () { el.remove(); }, 950);
  }

  /* ---------- Komentar ---------- */
  var cmt = DXComments.create({
    list: document.getElementById('commentList'),
    input: document.getElementById('commentField'),
    form: document.getElementById('commentForm'),
    onCount: function (n) {
      document.getElementById('commentCount').textContent = n;
      if (S.cmtItem) {
        S.cmtItem.comments = n;
        var c = feed.querySelector('.short-card[data-key="' + S.cmtItem.key + '"] .cnt-cmt'); if (c) c.textContent = n;
      }
    }
  });
  function openComments(it) {
    S.cmtItem = it; cmt.load(it.key);
    var me = document.getElementById('commentMe'); try { me.textContent = (dxUser.username || 'D')[0].toUpperCase(); } catch (e) {}
    document.body.classList.add('cmt-open'); sheet.classList.add('open'); backdrop.classList.add('open'); sheet.setAttribute('aria-hidden', 'false');
    if (matchMedia('(min-width: 900px)').matches) setTimeout(function () { document.getElementById('commentField').focus(); }, 350);
  }
  function closeComments() { document.body.classList.remove('cmt-open'); sheet.classList.remove('open'); backdrop.classList.remove('open'); sheet.setAttribute('aria-hidden', 'true'); S.cmtItem = null; }
  document.getElementById('closeComments').addEventListener('click', closeComments);
  backdrop.addEventListener('click', closeComments);

  /* ---------- Aksi kartu ---------- */
  async function share(it) {
    var url = location.origin + '/index.html#detail-' + it.type + '-' + it.id;
    try { if (navigator.share) { await navigator.share({ title: it.title, text: 'Tonton ' + it.title + ' di DXSTREAM', url: url }); return; } } catch (e) { if (e.name === 'AbortError') return; }
    try { await navigator.clipboard.writeText(url); toast('Link film disalin'); } catch (e) { toast(url); }
  }
  var lastTap = 0, tapTimer = null;
  function tapGesture(card, it, e) {
    var now = Date.now();
    if (now - lastTap < 280) { clearTimeout(tapTimer); lastTap = 0; burst(card, e); if (!it.liked) toggleLike(card, it, true); return; }
    lastTap = now;
    tapTimer = setTimeout(function () { if (card === S.playerCard) togglePlay(); }, 250);
  }
  feed.addEventListener('click', function (e) {
    var card = e.target.closest('.short-card');
    var act = e.target.closest('[data-act]');
    if (act && act.dataset.act === 'retry') { var m = document.getElementById('shortsMsg'); if (m) m.remove(); skeleton(); loadMore(); return; }
    if (!card) return;
    var it = S.items[+card.dataset.i]; if (!it) return;
    if (act) {
      switch (act.dataset.act) {
        case 'like': toggleLike(card, it); break;
        case 'comment': openComments(it); break;
        case 'share': share(it); break;
        case 'sponsors': card.classList.toggle('sponsors-open'); break;
        case 'mute': setMuted(S.userUnmuted); break;
        case 'fit': toggleFill(); break;
        case 'overview': card.classList.toggle('expanded'); break;
        case 'watch': if (window.openDetailModal) window.openDetailModal(it.id, it.type, true); break;
      }
      return;
    }
    if (e.target.closest('.short-tap')) tapGesture(card, it, e);
  });

  /* ---------- Navigasi ---------- */
  function goTo(i) {
    i = Math.max(0, Math.min(S.items.length - 1, i));
    var c = feed.children[i]; if (c) feed.scrollTo({ top: c.offsetTop, behavior: 'smooth' });
  }
  document.getElementById('shortsPrev').addEventListener('click', function () { goTo(S.activeIdx - 1); });
  document.getElementById('shortsNext').addEventListener('click', function () { goTo(S.activeIdx + 1); });
  document.addEventListener('keydown', function (e) {
    if (!S.visible || S.modalOpen || e.ctrlKey || e.metaKey || e.altKey) return;
    var tag = (e.target.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'textarea') { if (e.key === 'Escape') closeComments(); return; }
    var it = S.items[S.activeIdx], card = feed.children[S.activeIdx];
    switch (e.key) {
      case 'ArrowDown': case 'j': e.preventDefault(); goTo(S.activeIdx + 1); break;
      case 'ArrowUp': case 'k': e.preventDefault(); goTo(S.activeIdx - 1); break;
      case ' ': e.preventDefault(); togglePlay(); break;
      case 'ArrowRight': e.preventDefault(); seekBy(5); break;
      case 'ArrowLeft': e.preventDefault(); seekBy(-5); break;
      case 'm': setMuted(S.userUnmuted); break;
      case 'l': if (it && card) toggleLike(card, it); break;
      case 'c': if (it) openComments(it); break;
      case 'Escape': closeComments(); break;
    }
  });

  /* ---------- Siklus tampil/sembunyi ---------- */
  function show() {
    S.visible = true; document.body.classList.add('in-shorts');
    if (!S.items.length) { if (!S.loading) { skeleton(); loadMore(); } return; }
    var card = feed.children[Math.max(0, S.activeIdx)]; if (card && S.items[+card.dataset.i]) mount(card, S.items[+card.dataset.i]);
  }
  function hide() { S.visible = false; document.body.classList.remove('in-shorts'); unmount(); closeComments(); }

  new MutationObserver(function () {          // halaman film terbuka -> jeda Shorts; ditutup -> lanjut
    var open = !modal.classList.contains('hidden');
    if (open === S.modalOpen) return;
    S.modalOpen = open;
    if (open) unmount();
    else if (S.visible) { var c = feed.children[S.activeIdx]; if (c) mount(c, S.items[S.activeIdx]); }
  }).observe(modal, { attributes: true, attributeFilter: ['class'] });
  document.addEventListener('visibilitychange', function () {
    if (!S.player) return;
    if (document.hidden) { try { S.player.pauseVideo(); } catch (e) {} }
    else if (S.visible && !S.modalOpen && S.playerCard && !S.playerCard.classList.contains('paused')) { try { S.player.playVideo(); } catch (e) {} }
  });

  window.DXShorts = { show: show, hide: hide };
})();
