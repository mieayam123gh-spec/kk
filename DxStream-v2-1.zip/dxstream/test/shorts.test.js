const assert = require('assert');
const S = require('../lib/shorts');

// pickClip: Clip menang atas Trailer, resmi menang atas tidak resmi, non-YouTube dibuang
const vids = [
  { site: 'Vimeo', key: 'abcdefgh', type: 'Clip' },
  { site: 'YouTube', key: 'trailerKEY1', type: 'Trailer', official: true, iso_639_1: 'en' },
  { site: 'YouTube', key: 'clipKEYxxx1', type: 'Clip', official: false, iso_639_1: 'en' },
  { site: 'YouTube', key: 'bad key!', type: 'Clip', official: true },
  { site: 'YouTube', key: 'bloopersKEY', type: 'Bloopers', official: true }
];
assert.strictEqual(S.pickClip(vids).key, 'clipKEYxxx1');
assert.strictEqual(S.pickClip([]), null);
assert.strictEqual(S.pickClip(undefined), null);
assert.deepStrictEqual(S.clipWindow({ type: 'Trailer' }), { start: 12, end: 57 });
assert.deepStrictEqual(S.clipWindow({ type: 'Clip' }), { start: 0, end: 45 });

assert.ok(S.isValidKey('movie-123') && S.isValidKey('tv-9'));
assert.ok(!S.isValidKey('movie-') && !S.isValidKey('x-1') && !S.isValidKey('movie-1;drop') && !S.isValidKey(undefined));

// buildFeed dengan TMDB palsu
const calls = [];
const details = {
  '/movie/1': { id: 1, title: 'Satu', release_date: '2025-03-01', vote_average: 8.123, genres: [{ name: 'Aksi' }], poster_path: '/p.jpg', backdrop_path: '/b.jpg',
    production_companies: [{ name: 'Studio A', logo_path: '/a.png', origin_country: 'US' }, { name: 'Studio A' }], videos: { results: [{ site: 'YouTube', key: 'AAAAAAAAAAA', type: 'Teaser', official: true, iso_639_1: 'en' }] } },
  '/tv/2': { id: 2, name: 'Dua', first_air_date: '2024-01-01', networks: [{ name: 'Net B', logo_path: null }], videos: { results: [{ site: 'YouTube', key: 'BBBBBBBBBBB', type: 'Trailer' }] } },
  '/movie/3': { id: 3, title: 'Tanpa Video', videos: { results: [] } }
};
const tmdb = async (p, params) => {
  calls.push(p);
  if (p === '/trending/all/week') return { results: [{ id: 1, media_type: 'movie' }, { id: 2, media_type: 'tv' }, { id: 3, media_type: 'movie' }, { id: 4, media_type: 'person' }, { id: 5, media_type: 'movie' }] };
  if (details[p]) return details[p];
  throw new Error('404 ' + p);
};

(async () => {
  const { items } = await S.buildFeed({ tmdb, page: 1 });
  assert.strictEqual(items.length, 2, 'item tanpa video / gagal fetch / person harus dibuang');
  const one = items.find(i => i.key === 'movie-1');
  assert.strictEqual(one.rating, '8.1');
  assert.strictEqual(one.year, '2025');
  assert.strictEqual(one.video.yt, 'AAAAAAAAAAA');
  assert.deepStrictEqual(one.sponsors.map(s => s.name), ['Studio A'], 'sponsor harus unik');
  assert.strictEqual(one.sponsors[0].logo, 'https://image.tmdb.org/t/p/w185/a.png');
  const two = items.find(i => i.key === 'tv-2');
  assert.strictEqual(two.sponsors[0].kind, 'Jaringan');
  assert.strictEqual(two.video.start, 12);

  const before = calls.length;
  await S.buildFeed({ tmdb, page: 1 });
  const detailCalls = calls.slice(before).filter(c => c !== '/trending/all/week');
  assert.ok(detailCalls.every(c => c === '/movie/3' || c === '/movie/5'), 'item valid harus dari cache');

  // getShort memakai cache, key invalid -> null
  assert.strictEqual((await S.getShort(tmdb, 'movie-1')).title, 'Satu');
  assert.strictEqual(await S.getShort(tmdb, 'nope'), null);

  // halaman 2 memakai sumber berbeda
  const seen = [];
  await S.buildFeed({ tmdb: async p => { seen.push(p); return { results: [] }; }, page: 2 });
  assert.strictEqual(seen[0], '/discover/tv');
  console.log('shorts lib OK');
})().catch(e => { console.error(e); process.exit(1); });
